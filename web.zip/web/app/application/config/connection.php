<?php
    $server = "mariadb";
    $user = "root";
    $password = "azem16";
    $database = "laundry";

    $connection = mysqli_connect ($server, $user, $password, $database) or die(mysqli_error($connection));

?>
